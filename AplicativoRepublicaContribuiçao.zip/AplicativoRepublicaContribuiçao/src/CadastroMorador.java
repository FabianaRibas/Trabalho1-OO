import java.util.LinkedList;
import java.util.List;

public class CadastroMorador {
	
	List<Morador>ListaMorador;
	
	public CadastroMorador() {
		ListaMorador = new LinkedList<Morador>();
	}
	
	public boolean cadastrarMorador(Morador M) 
	{
		boolean resposta = false;
		if (ListaMorador == null) 
			ListaMorador = new LinkedList<Morador>();
		resposta = ListaMorador.add(M);
		return resposta;
	}

}
