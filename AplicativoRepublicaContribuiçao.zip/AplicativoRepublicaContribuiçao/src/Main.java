
import javax.swing.JOptionPane;

public class Main{
	
	static CadastroMorador m;
	static CadastroDespesa d;
	
	static final String opcoes[] = {
			
			"-- Escolha uma opcao --",
			"Cadastrar Morador",
			"Cadastrar Despesa",
			"Cadastrar Categoria",
			"Pesquisar Morador", 
			"Remover Morador", 
			"Salvar Cadastros", 
			"Ler Cadastros", 
			"Sair"
};
	
	public static void main(String[] args) {
		
		m = new CadastroMorador();
		d = new CadastroDespesa();
		
		Object opcao = JOptionPane.showInputDialog(null, "Escolha uma opcao", "Exemplo Persistencia", JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[0]);
		
		do {
			switch (opcao.toString()) 
			{
			case "Cadastrar Morador":
				CadastrarMorador();
				break;
			case "Cadastrar Despesa":
				CadastrarDespesa();
				break;
				
			case "Cadastrar Categoria":
				//CadastrarCategoria();
				break;
				
			case "Pesquisar Morador": 
				//PesquisarMorador();
				break;
			
			case "Remover Morador":
				//RemoverMorador();
				break;
			case "Salvar Cadastros":
				//SalvarCadastros();
				break;
			case "Ler Cadastros":
				//LerCadastros();
				break;				

			default:
				break;
			}
			
			opcao = JOptionPane.showInputDialog(null, "Escolha uma opcao", "Exemplo Persistencia", JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[0]);
			} while (!opcao.toString().equalsIgnoreCase(opcoes[8]));

	}

	private static boolean CadastrarDespesa() {
				
		String repetir = "sim";
		do {
		//String categoria = JOptionPane.showInputDialog("Categoria da Despesa");
		String descricao = JOptionPane.showInputDialog("Descrição da Despesa");
		String valor = JOptionPane.showInputDialog("Valor da Despesa");
		
		float valores = Float.parseFloat(valor);
		
		Despesas D = new Despesas(descricao,valores);
		
		boolean resposta = d.cadastrarDespesa(D);
		
		if (resposta)
			JOptionPane.showMessageDialog(null, "Despesas cadastrada com sucesso!!");
		
		return resposta;
		
		String repetir = JOptionPane.showInputDialog("Deseja cadastrar outra despesa?");
		
		}while(repetir.equalsIgnoreCase("Sim"));
	}

	private static boolean CadastrarMorador() 
	{
			String nome = JOptionPane.showInputDialog("Nome do Morador");
			String email = JOptionPane.showInputDialog("Email do Morador");
			String rendimentos = JOptionPane.showInputDialog("Rendimento do Morador");
			
			float rendimento = Float.parseFloat(rendimentos);
			
			Morador M = new Morador(nome, email, rendimento);
			
			boolean resposta = m.cadastrarMorador(M);
			
			if (resposta)
				JOptionPane.showMessageDialog(null, "Morador cadastrado com sucesso!");
			return resposta;
	}
		
	}
