//import java.util.LinkedList;
//import java.util.List;

public class Categorias {
	private String nome;
	private String subcategoria;
	
	
	public Categorias(String nome, String subcategoria) {
		this.nome = nome;
		this.subcategoria = subcategoria;
	}

	public String getNome() {
		return nome;
	}
	

	public String getSubcategoria() {
		return subcategoria;
	}

	

	/*public void addDispesa(Despesas D)
	{
		D.setCategoria(this);
		ListaDespesas.add(D);
	}*/


}
